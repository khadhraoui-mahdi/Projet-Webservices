package de.tekup.endpoint.controller;

import de.tekup.endpoint.pojo.ProfileModel;
import de.tekup.endpoint.pojo.RequestModel;
import de.tekup.endpoint.service.ProfileService;
import de.tekup.endpoint.service.SOAPService;
import de.tekup.endpoint.service.Transformer;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;


import javax.servlet.http.HttpServletRequest;

import java.util.*;/*
import java.util.List;
import java.util.Map;*/

@RestController
@RequestMapping("/call/v")
public class RestApiController {
    @Autowired private SOAPService soapService;
    @Autowired private ProfileService profileService;
    @Autowired private RestTemplate restTemplate;
    private static String url="https://restcountries.com/v3.1/all";
    
    
    @RequestMapping(value = "/countries", method = RequestMethod.GET)
    public List<Object> getCountries(){
    	Object[] countries = restTemplate.getForObject(url, Object[].class);
    	return Arrays.asList(countries);
    }
    
    
    @RequestMapping(value = "/restCountry", method = RequestMethod.GET)
    public ResponseEntity<?> getCountrys() {
        try {
            //String ur="https://restcountries.com/v3.1/all";
            //RestTemplate restTemplate = new RestTemplate();
            String result = restTemplate.getForObject(url, String.class);
            return new ResponseEntity<>(result, HttpStatus.OK);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseEntity<>("Error!, Please try again", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    

    @RequestMapping(value = "/convertSoapToRest", method = RequestMethod.POST,
             consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<?> convertSoapToRest(HttpServletRequest request,
                                               @RequestBody RequestModel soapRequestModel) throws Exception {
        return new ResponseEntity<Object>(soapService.call(soapRequestModel.getWsdlUrl(),soapRequestModel.getWsdlOperationName(),
            soapRequestModel.getOperationKeyMap()), HttpStatus.OK);
    }

    @RequestMapping(value = "/explore", method = RequestMethod.POST,
        consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<?> save(@RequestBody ProfileModel profileModel) throws Exception{
        return new ResponseEntity<Object>(profileService.saveProfile(profileModel),HttpStatus.OK);
    }

    @RequestMapping(value = "/execute/{serviceName}/{operationName}", method = RequestMethod.GET,
    produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public ResponseEntity<?> execute(@PathVariable String serviceName,
        @RequestHeader(value = "X-Transformation", defaultValue = "false") Boolean transformation,
        @PathVariable String operationName,
        @RequestParam Map<String,Object> params) throws Exception{
        JSONObject response = profileService.execute(serviceName,operationName,params);
        return new ResponseEntity<Object>(transformation ? Transformer.transforResponse(response).toString() : response.toString(),HttpStatus.OK);
    }

}

