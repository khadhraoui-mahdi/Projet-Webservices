package de.tekup.endpoint.constants;


public class AppConstant {
    public static final String PARAMS_REGEX = ">.*[?].*>";
}
